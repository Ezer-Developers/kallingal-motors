from django.contrib import admin
from .models import CompressedImage

# Register your models here.
admin.site.register(CompressedImage)